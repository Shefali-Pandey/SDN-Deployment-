Switch Configuration Examples for Microsoft SDN

This folder contains a tree of example configuration files for various 
physical switch / router vendors that have been created and used by Microsoft in testing 
SDN scenarios.  You can use these as examples when setting up your own SDN 
environment.
