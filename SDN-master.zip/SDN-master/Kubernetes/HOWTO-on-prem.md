Please refer to the [official MSDN documentation](https://docs.microsoft.com/en-us/virtualization/windowscontainers/kubernetes/getting-started-kubernetes-windows) for setup instructions.
