# Usage

- Leverage this ubuntu box as an easy way for primarily Windows users to compile k8s
- Reference on requirements for Ubuntu 16.04 to not run into delays/issues

## Typical usage

- `vagrant up`
- `vagrant ssh`
- Run commands in main readme to compile k8s for linux and windows. Copy out files via SCP or other tools